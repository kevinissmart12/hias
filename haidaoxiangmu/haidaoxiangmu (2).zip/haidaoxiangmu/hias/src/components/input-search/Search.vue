<template>
    <div class="search">

    </div>
</template>

<script>
export default {
    name:"search",
    prop:{

    },
    data(){
        return{

        }
    },
    methods:{

    },
}
</script>

<style lang="less" scoped>

</style>