<template>
    <div class="products">
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name:'products',
    data(){
        return{

        }
    }
}
</script>

<style lang="less" scoped>

</style>