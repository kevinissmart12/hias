<template>
    <div class="ponds">
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name:'Ponds'
}
</script>

<style lang='less' scoped>
    .ponds{
        width: 100%;
        height: 100%;
    }
</style>