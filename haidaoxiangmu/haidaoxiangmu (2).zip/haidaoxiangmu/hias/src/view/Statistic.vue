<template>
    <div class="statistic">
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name:'statistic',
    data(){
        return{

        }
    }
}
</script>

<style lang="less" scoped>

</style>