<template>
    <div class="owner">
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name:'owner'
}
</script>

<style lang="less" scoped>
    .owner{
        width: 100%;
        height: 100%;
    }
</style>