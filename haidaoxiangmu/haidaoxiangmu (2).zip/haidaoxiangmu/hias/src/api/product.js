const Product={

    type:[
        {id:0,content:'硬骨鱼纲'},
        {id:1,content:'双壳纲'},
        {id:2,content:'甲壳纲'},
        {id:3,content:'软甲纲'},
    ],

    breedMethod:[
        {id:0,content:'滩涂养殖'},
        {id:1,content:'围塘养殖'},
        {id:2,content:'大棚养殖'},
        {id:3,content:'网箱养殖/围网养殖/土池养殖'},
        {id:4,content:'吊绳养殖/插柱养殖/打桩养殖'},

    ]
    

}

export default Product