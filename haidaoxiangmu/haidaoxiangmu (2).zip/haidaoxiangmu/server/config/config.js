module.exports={
    secretKey:"wangkai9190604119",
    time:3600,
    UnIdentifiedPath:[
        '/api/user/login',
        '/api/user/register',
        '/api/user/resetPwd',

    ],
}